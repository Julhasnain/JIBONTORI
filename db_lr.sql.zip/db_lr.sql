-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2017 at 02:02 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_lr`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `last_donated` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT '0',
  `contact` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `email`, `password`, `blood_group`, `last_donated`, `age`, `contact`) VALUES
(2, 'Imran Hossain', 'imran', 'imran@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'B+', '21-05-2016', 0, 0),
(3, 'Julhasnain', 'julu_sir', 'sir@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A+', '13-11-2016', 0, 0),
(4, 'Rashid al Shafee', 'uncensored_king', 'uncensored@pitani.com', '81dc9bdb52d04dc20036dbd8313ed055', 'O+', '21-12-2015', 0, 0),
(5, 'Mehadi Hasan', 'tiger', 'tiger@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'O-', '25-07-2016', 0, 0),
(6, 'Shahbaz Abdullah', 'sanim', 'sanim@yahoo.com', '827ccb0eea8a706c4c34a16891f84e7b', 'AB+', '10-04-2014', 0, 0),
(7, 'Tohidul Alam', 'mitunTop', 'mitun@toplevel.com', '827ccb0eea8a706c4c34a16891f84e7b', 'O+', '20-01-2017', 0, 0),
(8, 'SK Saiful', 'pk_saiful', 'pk@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A-', '06-10-2016', 0, 0),
(9, 'Arman Ovi', 'tanzina', 'tanzina@abegi.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A-', '05-09-2016', 0, 0),
(22, 'Nayan Pal', 'nayan', 'nayan@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'B-', '10-01-2017', 0, 0),
(11, 'Kalyan Brata Chakrabarty', '50lakhs', 'amit@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'B-', '20-12-2011', 0, 0),
(12, 'Zahid Hasan', 'tuhin', 'tuhin@toplevel.com', '827ccb0eea8a706c4c34a16891f84e7b', 'AB-', '29-07-2016', 0, 0),
(13, 'Rakibul Huda', 'rakib', 'rakib@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'O+', '01-01-2017', 21, 12345678),
(14, 'Irfanul Karim', 'dollar_karim', 'dollar@taka.com', '827ccb0eea8a706c4c34a16891f84e7b', 'B+', '01-01-2017', 0, 0),
(15, 'Mahmudul Hasan', 'shohag', 'shohag@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A+', '01-02-2017', 0, 0),
(21, 'Ahsanul Kabir', 'talent', 'cg4ahsan@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'B-', '01-01-2017', 0, 0),
(17, 'Sina Ibn Amin', 'Sina', 'hoi@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'AB+', '01-01-2017', 0, 0),
(20, 'Sayem Chowdhury', 'rice_bepari', 'chail@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A-', '01-01-2017', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `pro_name` text NOT NULL,
  `pro_value` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `username`, `pro_name`, `pro_value`) VALUES
(1, 'rice_bepari', 'user', 0),
(2, 'rakib', 'admin', 9),
(3, 'imran', 'user', 0),
(4, 'uncensored_king', 'user', 0),
(5, 'talent', 'user', 0),
(6, 'talent', 'user', 0),
(7, 'nayan', 'user', 0),
(8, 'julu_sir', 'admin', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
