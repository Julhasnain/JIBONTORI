-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2017 at 03:41 AM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_lr`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `last_donated` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `email`, `password`, `blood_group`, `last_donated`) VALUES
(2, 'Imran Hossain', 'imran', 'imran@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'B+', '21-05-2016'),
(3, 'Julhasnain', 'julu_sir', 'sir@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A+', '13-11-2016'),
(4, 'Rashid al Shafee', 'uncensored_king', 'uncensored@pitani.com', '81dc9bdb52d04dc20036dbd8313ed055', 'O+', '21-12-2015'),
(5, 'Mehadi Hasan', 'tiger', 'tiger@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'O-', '25-07-2016'),
(6, 'Shahbaz Abdullah', 'sanim', 'sanim@yahoo.com', '827ccb0eea8a706c4c34a16891f84e7b', 'AB+', '10-04-2014'),
(7, 'Tohidul Alam', 'mitunTop', 'mitun@toplevel.com', '827ccb0eea8a706c4c34a16891f84e7b', 'O+', '20-01-2017'),
(8, 'SK Saiful', 'pk_saiful', 'pk@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A-', '06-10-2016'),
(9, 'Arman Ovi', 'tanzina', 'tanzina@abegi.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A-', '05-09-2016'),
(10, 'Ahsanul Kabir', 'talent', 'cg4ahsan@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'B-', '09-07-2016'),
(11, 'Kalyan Brata Chakrabarty', '50lakhs', 'amit@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'B-', '20-12-2011'),
(12, 'Zahid Hasan', 'tuhin', 'tuhin@toplevel.com', '827ccb0eea8a706c4c34a16891f84e7b', 'AB-', '29-07-2016'),
(13, 'Rakibul Huda', 'rakib', 'rakib@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'O+', '31-01-2017'),
(14, 'Irfanul Karim', 'dollar_karim', 'dollar@taka.com', '827ccb0eea8a706c4c34a16891f84e7b', 'B+', '01-01-2017');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
