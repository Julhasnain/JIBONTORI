-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2017 at 04:13 PM
-- Server version: 10.1.24-MariaDB
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jibontori`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `last_donated` varchar(255) DEFAULT NULL,
  `age` varchar(5) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `email`, `password`, `blood_group`, `last_donated`, `age`, `contact`) VALUES
(2, 'Imran Hossain', 'imran', 'imran@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'B+', '21-05-2016', '0', '0'),
(3, 'Julhasnain', 'julhas', 'julhas@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A+', '13-11-2016', '25', '123456789'),
(4, 'Rashid al Shafee', 'shafee', 'shafee@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'O+', '21-12-2015', '0', '0'),
(5, 'Mehadi Hasan', 'hridoy', 'hridoy@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'O-', '25-07-2016', '0', '0'),
(6, 'Shahbaz Abdullah', 'sanim', 'sanim@yahoo.com', '827ccb0eea8a706c4c34a16891f84e7b', 'AB+', '10-04-2014', '0', '0'),
(7, 'Tohidul Alam', 'mitun', 'mitun@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'O+', '20-01-2017', '0', '0'),
(8, 'SK Saiful', 'saiful', 'saiful@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'A-', '07-10-2016', '', '0'),
(9, 'Arman Ovi', 'ovi', 'ovi@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A-', '05-09-2016', '0', '0'),
(22, 'Nayan Pal', 'nayan', 'nayan@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'B-', '10-01-2017', '0', '0'),
(11, 'Kalyan Brata Chakrabarty', 'amit', 'amit@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'B-', '20-12-2011', '0', '0'),
(12, 'Zahid Hasan', 'tuhin', 'tuhin@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'AB-', '29-07-2016', '0', '0'),
(13, 'Rakibul Huda', 'rakib', 'rakib@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'O+', '01-04-2017', '22', '01123456789'),
(14, 'Irfanul Karim', 'irfan', 'irfan@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'B+', '01-01-2017', '0', '0'),
(15, 'Mahmudul Hasan', 'shohag', 'shohag@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A+', '01-02-2017', '25', '0'),
(21, 'Ahsanul Kabir', 'sajid', 'sajid@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'AB-', '01-01-2017', '0', '3543138436343'),
(17, 'Sina Ibn Amin', 'sina', 'sina@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'AB+', '01-01-2017', '0', '0'),
(20, 'Sayem Chowdhury', 'sayem', 'sayem@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A-', '01-01-2017', '0', '0'),
(24, 'Shahriar Rifat', 'rifat', 'rifat@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'A-', '01-02-2017', '32', '0'),
(31, 'Jaker Hossain', 'jaker', 'jaker@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Unknown', '', ' ', ' ');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `pro_name` text NOT NULL,
  `pro_value` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `username`, `pro_name`, `pro_value`) VALUES
(1, 'sayem', 'user', 0),
(2, 'rakib', 'admin', 9),
(3, 'imran', 'user', 0),
(4, 'shafee', 'user', 0),
(5, 'sajid', 'user', 0),
(7, 'nayan', 'user', 0),
(8, 'julhas', 'admin', 9),
(9, 'rifat', 'user', 0),
(10, 'tuhin', 'user', 0),
(11, 'sanim', 'admin', 9),
(12, 'mitun', 'user', 0),
(13, 'saiful', 'user', 0),
(14, 'ovi', 'user', 0),
(15, 'amit', 'user', 0),
(16, 'irfan', 'user', 0),
(17, 'shohag', 'user', 0),
(18, 'sina', 'user', 0),
(19, 'rifat', 'user', 0),
(21, 'jaker', 'user', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
